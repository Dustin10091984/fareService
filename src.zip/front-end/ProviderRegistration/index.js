import Registration from './Registration.container';
export default Registration;
