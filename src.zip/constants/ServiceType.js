const ServiceType = {
    MOVING: 'MOVING',
    MULTIPLE: 'MULTIPLE',
};

export default ServiceType;
