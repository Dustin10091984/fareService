import MyAccount from './MyAccount.container';
export { MyAccount };