import { createContext } from "react";
const MapLoadedApiContext = createContext(false);
const LoginContext = createContext(false);

export { MapLoadedApiContext, LoginContext };